from flask import Flask, render_template, request, redirect, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
import os
import csv

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database connection
def get_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='Sai@2006',
        database='online_voting_system'
    )

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, password))
        conn.commit()
        return redirect('/')
    return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()

    if user and check_password_hash(user['password'], password):
        session['user_id'] = user['id']
        session['name'] = user['name']
        return redirect('/vote')

    return "Invalid login"

@app.route('/vote', methods=['GET', 'POST'])
def vote():
    if 'user_id' not in session:
        return redirect('/')

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT has_voted FROM users WHERE id = %s", (session['user_id'],))
    voted = cursor.fetchone()['has_voted']

    if voted:
        return redirect('/result')

    if request.method == 'POST':
        candidate_id = request.form['candidate']
        cursor.execute("UPDATE candidates SET votes = votes + 1 WHERE id = %s", (candidate_id,))
        cursor.execute("UPDATE users SET has_voted = TRUE WHERE id = %s", (session['user_id'],))
        conn.commit()
        return redirect('/result')

    cursor.execute("SELECT * FROM candidates")
    candidates = cursor.fetchall()
    return render_template('vote.html', candidates=candidates)

@app.route('/result')
def result():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM candidates ORDER BY votes DESC")
    candidates = cursor.fetchall()

    # Save to CSV file in "results" folder
    folder = os.path.join(os.getcwd(), "results")
    os.makedirs(folder, exist_ok=True)
    filepath = os.path.join(folder, "voting_results.csv")

    with open(filepath, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Name', 'Party', 'Votes'])
        for c in candidates:
            writer.writerow([c['name'], c['party'], c['votes']])

    return render_template('result.html', candidates=candidates)

if __name__ == '__main__':
    app.run(debug=True)