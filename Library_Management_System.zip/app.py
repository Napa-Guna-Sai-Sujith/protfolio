
from flask import Flask, render_template, request, redirect
import mysql.connector
from datetime import datetime

app = Flask(__name__)

# MySQL connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword",
    database="library_management"
)
cursor = conn.cursor(dictionary=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/books')
def view_books():
    cursor.execute("SELECT * FROM books")
    books = cursor.fetchall()
    return render_template('view_books.html', books=books)

@app.route('/add', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        total = int(request.form['total'])
        query = "INSERT INTO books (title, author, total_copies, available_copies) VALUES (%s, %s, %s, %s)"
        cursor.execute(query, (title, author, total, total))
        conn.commit()
        return redirect('/books')
    return render_template('add_book.html')

@app.route('/issue', methods=['GET', 'POST'])
def issue_book():
    if request.method == 'POST':
        student_id = request.form['student_id']
        book_id = request.form['book_id']
        cursor.execute("SELECT available_copies FROM books WHERE book_id=%s", (book_id,))
        book = cursor.fetchone()
        if book and book['available_copies'] > 0:
            cursor.execute("INSERT INTO issued_books (student_id, book_id, issue_date) VALUES (%s, %s, %s)",
                           (student_id, book_id, datetime.now()))
            cursor.execute("UPDATE books SET available_copies = available_copies - 1 WHERE book_id = %s", (book_id,))
            conn.commit()
        return redirect('/books')
    return render_template('issue_book.html')

@app.route('/return', methods=['GET', 'POST'])
def return_book():
    if request.method == 'POST':
        issue_id = request.form['issue_id']
        cursor.execute("SELECT book_id FROM issued_books WHERE issue_id = %s", (issue_id,))
        book = cursor.fetchone()
        if book:
            cursor.execute("UPDATE books SET available_copies = available_copies + 1 WHERE book_id = %s", (book['book_id'],))
            cursor.execute("UPDATE issued_books SET return_date = %s WHERE issue_id = %s", (datetime.now(), issue_id))
            conn.commit()
        return redirect('/books')
    return render_template('return_book.html')

if __name__ == '__main__':
    app.run(debug=True)
