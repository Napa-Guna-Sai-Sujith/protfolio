from flask import Flask, render_template, request, redirect
import sqlite3
import os

app = Flask(__name__, template_folder='templates')

# Ensure database and table are created
def init_db():
    if not os.path.exists('student_mgmt.db'):
        conn = sqlite3.connect('student_mgmt.db')
        conn.execute('''
            CREATE TABLE students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                dob TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()

def get_db_connection():
    conn = sqlite3.connect('student_mgmt.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        dob = request.form['dob']
        email = request.form['email']
        phone = request.form['phone']

        conn = get_db_connection()
        conn.execute("INSERT INTO students (name, dob, email, phone) VALUES (?, ?, ?, ?)",
                     (name, dob, email, phone))
        conn.commit()
        conn.close()
        return redirect('/students')
    return render_template('add_students.html')

@app.route('/students')
def students():
    conn = get_db_connection()
    students = conn.execute("SELECT * FROM students").fetchall()
    conn.close()
    return render_template('view_students.html', students=students)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
